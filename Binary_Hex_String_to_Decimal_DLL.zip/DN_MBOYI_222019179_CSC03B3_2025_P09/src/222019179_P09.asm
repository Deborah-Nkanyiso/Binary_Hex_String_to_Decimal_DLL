;	Update all of this information to reflect your own details and the practical
;	Author:	DN MBOYI 222019179
;	P09 DLL starter file
.386
.MODEL FLAT, stdcall
.STACK 4096

.CODE

; LibMain function tests which action is currently beign performed
; The function returns if the DLL is loaded correctly or not.
; We avoid the complex logic here for simplicity.
LibMain proc instance:DWORD, reason:DWORD, unused:DWORD
	mov eax, 1
  ret
LibMain ENDP

;Converts the string representation of a binary number to decimal
; Max length of the string is 8 but can be shorter
; e.g. "00000101" = 6
binStringToDecimal PROC NEAR32
PUSH EBP
MOV EBP, ESP
PUSH EBX
PUSH ECX
PUSH EDX
    
MOV EAX, [EBP+8]       
XOR EDX, EDX           
XOR ECX, ECX           
    
 
MOV BL, [EAX]          
TEST BL, BL            
JE invalid_binString

binString_loop:
MOV BL, [EAX]         
TEST BL, BL            
JZ binString_done
    
; Validate character is '0' or '1'
CMP BL, '0'
JB invalid_binString
CMP BL, '1'
JA invalid_binString
    

SUB BL, '0'
    
SHL EDX, 1
ADD EDX, EBX           
    
INC EAX               
INC ECX               
CMP ECX, 8
JA invalid_binString
    
JMP binString_loop

binString_done:
MOV EAX, EDX           
POP EDX
POP ECX
POP EBX
POP EBP
RET 4

invalid_binString:
MOV EAX, -1
POP EDX
POP ECX
POP EBX
POP EBp
RET 4
	; TODO
binStringToDecimal ENDP

;Converts the string representation of a hexadecimal number to decimal
; Max length of the string is 4 but can be shorter
hexStringToDecimal PROC NEAR32
PUSH EBP
MOV EBP, ESP
PUSH EBX
PUSH ECX
PUSH EDX
    
MOV EAX, [EBP+8]       
XOR EDX, EDX           
XOR ECX, ECX          
    

MOV BL, [EAX]          
TEST BL, BL            
JE invalid_hexString
    
hexString_loop:
MOV BL, [EAX]          
TEST BL, BL            
JZ hexString_done
  

CMP BL, '0'
JB check_upperString
CMP BL, '9'
JA check_upperString
    
SUB BL, '0'
JMP addDigit
    
check_upperString:
CMP BL, 'A'
JB check_lowerString
CMP BL, 'F'
JA check_lowerString
    
SUB BL, 'A' - 10
JMP addDigit
    
check_lowerString:
CMP BL, 'a'
JB invalid_hexString
CMP bl, 'f'
JA invalid_hexString
    
SUB BL, 'a' - 10
    
addDigit:
SHL EDX, 4
ADD EDX, EBX           
    
INC EAX                
INC ECX               
CMP ECX, 4
JA invalid_hexString
    
JMP hexString_loop

hexString_done:
MOV EAX, EDX           ; Move result to EAX
POP EDX
POP ECX
POP EBX
POP EBP
RET 4

invalid_hexString:
MOV EAX, -1
POP EDX
POP ECX
POP EBX
POP EBP
RET 4
	; TODO
hexStringToDecimal ENDP

end LibMain
